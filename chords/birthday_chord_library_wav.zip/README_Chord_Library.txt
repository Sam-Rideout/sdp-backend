Birthday Chord Library

12 major + 12 minor WAV chords.
Format: 44.1 kHz, 16-bit stereo WAV, 4 seconds each, peak normalized around -3 dB.
Use as chord beds behind personalized name overlay.

CMS fields: nameChord, nameChordKey, nameChordType, nameChordGain.
